// Shared types for auth flows.
export type OtpDigit = string;
export type OtpArray = [OtpDigit, OtpDigit, OtpDigit, OtpDigit, OtpDigit, OtpDigit];
